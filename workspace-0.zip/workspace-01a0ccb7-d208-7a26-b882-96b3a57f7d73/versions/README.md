# نسخه‌های HTML2Elementor

جدیدترین نسخه: **HTML2Elementor-Windows-v1.7.0.zip**

- `HTML2Elementor-Windows-v1.7.0.zip`

بسته‌های قبلی بنا به درخواست حذف شده‌اند و بازسازی نشده‌اند. فقط ZIPهای موجود فهرست می‌شوند. manifest.json شامل SHA-256 و اندازه فایل‌هاست. بستهٔ تجمیعی تکراری ساخته نمی‌شود.
